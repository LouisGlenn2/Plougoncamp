package camping;

import java.util.ArrayList;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.StringConverter;
/**
 * 
 * @author Marius Gaudin
 * 01/06/2019
 */
public class FenAjouterReservation extends Stage{
	
	private VBox root = new VBox();
	private HBox contenu = new HBox();
	private VBox menu = new VBox();
	private TableView<Emplacement> listEmplacements = new TableView<Emplacement>();
	
	private Label labTitre = new Label("PlougonCamp");
	private Button btValider = new Button("Suivant");
	private Button btAnnuler = new Button("Annuler");
	private Label labErreur = new Label("Erreur de saisie");
	
	private Label labTypeEmpl = new Label("Type d'emplacement");
	private ComboBox<String> chxTypeEmpl = new ComboBox<String>();
	
	private Label labNbPerson = new Label("Nombre de personnes");
	private TextField chxNbPerson = new TextField("0");
	private int nbPersonne;
	
	private boolean valChange = false;
	private boolean selectDateDebut = false;
	private boolean selectDateFin = false;
	
	private Label labDateDebut = new Label("Date de debut de s�jour");
	private DatePicker chxDateDebut = new DatePicker(); 
	
	private Label labDateFin = new Label("Date de fin de s�jour");
	private DatePicker chxDateFin = new DatePicker(); 
	
	public FenAjouterReservation()
	{
		
		this.setTitle("Plougoncamp");
		
		Scene laScene = new Scene(creerContenu());
		this.setScene(laScene);
		this.sizeToScene();
	}
	
	public int getNbPersonne()
	{
		return nbPersonne;
	}
	
	public LocalDate getDateDebut()
	{
		return chxDateDebut.getValue();
	}
	
	public LocalDate getDateFin()
	{
		return chxDateFin.getValue();
	}
	
	public Emplacement getEmplacement()
	{
		return Main.getLesEmplacements().get(listEmplacements.getSelectionModel().getSelectedIndex());
	}
		
	Parent creerContenu()
	{
		btValider.setOnAction(e -> {Main.ouvrirFenFormulaire();this.close();});
		btAnnuler.setOnAction(e -> this.close());
		labTitre.setFont(new Font("Arial", 30));	
		menu.setAlignment(Pos.CENTER);
		root.setAlignment(Pos.CENTER);
		root.setSpacing(20);
		root.setPadding(new Insets(10));
		contenu.setSpacing(100);
		menu.setSpacing(10);
		
		griserBouton();
		listEmplacements.setOnMouseClicked(e -> griserBouton());
		
		chxDateDebut.setDayCellFactory(picker -> new DateCell() {
			/**
			 * 
			 * Impossible de selectionner une date avant la date d'aujourd'hui
			 */
		        public void updateItem(LocalDate date, boolean empty) {        
		            super.updateItem(date, empty);
		            LocalDate today = LocalDate.now();

		            setDisable(empty || date.compareTo(today) < 0 );
		        }
		    });
		/**
		 * Impossible de selectionner une date avant la date d'aujourd'hui
		 */
		chxDateFin.setDayCellFactory(picker -> new DateCell() {                 
	        public void updateItem(LocalDate date, boolean empty) {
	            super.updateItem(date, empty);
	            LocalDate today = LocalDate.now();

	            setDisable(empty || date.compareTo(today) < 0 );
	        }
	    });
		
		
		chxDateDebut.valueProperty().addListener(e -> {refreshDateFin();});
		chxDateFin.valueProperty().addListener(e -> {refreshDateDebut();});
		
		chxTypeEmpl.getItems().addAll("Terrain Nu", "MobilHome");
		chxTypeEmpl.setOnAction(e -> trierParType());
		chxNbPerson.textProperty().addListener(e -> trierParNbPers());
		
		root.setPadding(new Insets(20));
		
		root.setMaxHeight(900);
		
		labErreur.setTextFill(Color.RED);
		labErreur.setVisible(false);
		menu.getChildren().addAll(labTypeEmpl, chxTypeEmpl, labDateDebut, chxDateDebut, labDateFin, chxDateFin, labNbPerson, chxNbPerson, labErreur);
		contenu.getChildren().addAll(menu, listEmplacements);
		root.getChildren().addAll(labTitre, contenu, btValider, btAnnuler);
		return root;	
	}
	/**
	 * creer le tableau qui affiche la liste des emplacements disponible
	 */
	
	public void creerTable()
	{	
		for(int i=0;i<Main.NB_MOBILHOME+Main.NB_TERRAIN_NU;i++)
		{
			Main.getLesEmplacements().add(Main.getEmplacement().get(i));
		}
		
		
		listEmplacements.setPrefSize(600, 600);
		/**
		 * creer les colonnes du tableau
		 */
		TableColumn<Emplacement, String> numCol = new TableColumn<Emplacement, String>("Numero");
		TableColumn<Emplacement, String> nbpCol = new TableColumn<Emplacement, String>("Nombre de places");
		TableColumn<Emplacement, String> typeCol = new TableColumn<Emplacement, String>("Type d'emplacement");
		
		numCol.setMinWidth(150);
		nbpCol.setMinWidth(200);
		typeCol.setMinWidth(200);
		/**
		 * definir les valeurs associe au colonnes
		 */
		numCol.setCellValueFactory( new PropertyValueFactory<Emplacement, String>("numeroEmp"));	 
		nbpCol.setCellValueFactory(new PropertyValueFactory<Emplacement, String>("nbPlaces"));
		typeCol.setCellValueFactory(new PropertyValueFactory<Emplacement, String>("typeEmplacement"));
		/**
		 * faire le lien entre les observableList (dans le main) et la tableView
		 */
		listEmplacements.setItems(Main.getLesEmplacements()); 
		/**
		 * ajouter toutes les colonnes
		 */
		listEmplacements.getColumns().addAll(numCol, nbpCol, typeCol); 
		
	}
	/**
	 * Cette methode permet de trier la liste en fonction du type d'emplacement selectionne par l'utilisateur
	 */
	
	public void trierParType()
	{
		try
		{
			if(chxTypeEmpl.getValue().equals("Terrain Nu")) //Si on selectionne le type terrain nu
			{
				Main.getLesEmplacements().clear();
				for(int i=0; i<Main.getEmplacement().size();i++)
				{
					if(Main.getEmplacement().get(i).getTypeEmplacement().equals("Terrain Nu"))
					{
						Main.getLesEmplacements().add(Main.getEmplacement().get(i));
					}
				}
				
			}
			/**
			 * Si on selectionne le type mobilHome
			 */
			else if(chxTypeEmpl.getValue().equals("MobilHome"))  
			{
				Main.getLesEmplacements().clear();
				for(int i=0; i<Main.getEmplacement().size();i++)
				{
					if(Main.getEmplacement().get(i).getTypeEmplacement().equals("MobilHome"))
					{
						Main.getLesEmplacements().add(Main.getEmplacement().get(i));
					}
				}
				
			}
		}
		/**
		 * //Si aucune selection dans la comboBox
		 */
		catch(NullPointerException e) 
		{
			Main.getLesEmplacements().clear();
			for(int i=0;i<Main.NB_MOBILHOME+Main.NB_TERRAIN_NU;i++)
			{
				Main.getLesEmplacements().add(Main.getEmplacement().get(i));
			}
		}
		/**
		 * // si une valeur a deja ete rentre dans choix nombre de personnes
		 */
		if(valChange) 
		{
			trierParNbPers();
		}
		
		trierParDate();
		
	}
	/**
	 * Cette methode permet de trier la liste en fonction du nombre de personne selectionne par l'utilisateur
	 */
	public void trierParNbPers()
	{
		valChange = false; //La valeur n'est pas accepte
		trierParType(); //trier tous d'abord par type
		
		try
		{
			int nbPers = Integer.parseInt(chxNbPerson.getText());
			if(nbPers > 0)
			{
				this.nbPersonne = nbPers;
				int i = 0;
				while(i<Main.getLesEmplacements().size())
				{
					if(Main.getLesEmplacements().get(i).getNbPlaces() < nbPers)
					{
						Main.getLesEmplacements().remove(i);
					}
					else
					{
						i++;
					}
				}
				labErreur.setVisible(false);
				valChange = true; //La valeur est accepte
			}
			else
			{
				labErreur.setVisible(true);
			}
		}
		catch(NumberFormatException e)
		{
			labErreur.setVisible(true);
		}
		
		trierParDate();
		griserBouton();
	}
	/**
	 * Cette methode permet de trier la liste en fonction de la date selectionne par l'utilisateur
	 */
	public void trierParDate()
	{
		if(chxDateDebut.getValue() != null)
		{
	
			for(int i=0;i<Main.getReservation().size();i++)
			{
				if(chxDateDebut.getValue().compareTo(Main.getReservation().get(i).getDate_Debut()) >= 0 && chxDateDebut.getValue().compareTo(Main.getReservation().get(i).getDate_Fin()) <= 0 || chxDateDebut.getValue().compareTo(Main.getReservation().get(i).getDate_Debut()) >= 0 && chxDateFin.getValue().compareTo(Main.getReservation().get(i).getDate_Fin()) <= 0)
				{
					Main.getLesEmplacements().remove(Main.getLesReservation().get(i).getEmplacement());
				}
			}
			
		}
	}
	/**
	 * permet de ne pas selectionner une date anterieur a date de fin	
	 */
	
	public void refreshDateFin() {
		trierParDate();
		chxDateFin.setDayCellFactory(picker -> new DateCell() {
	        public void updateItem(LocalDate date, boolean empty) {
	            super.updateItem(date, empty);
	            LocalDate debut = chxDateDebut.getValue();

	            setDisable(empty || date.compareTo(debut) < 0 );
	        }
	    });
		
		selectDateDebut = true;
		griserBouton();
	}
	
	public void refreshDateDebut()//permet de ne pas selectionner une date anterieur a date de debut
	{
		trierParDate();
		chxDateDebut.setDayCellFactory(picker -> new DateCell() {
	        public void updateItem(LocalDate date, boolean empty) {
	            super.updateItem(date, empty);
	            LocalDate fin = chxDateFin.getValue();
	            LocalDate today = LocalDate.now();
	            setDisable(empty || date.compareTo(fin) > 0 || date.compareTo(today) < 0 );
	           
	        }
	    });
		
		selectDateFin = true;
		griserBouton();
	}
	
	public void griserBouton()
	{
		if(valChange && selectDateDebut && selectDateFin && listEmplacements.getSelectionModel().getSelectedIndex() != -1)
		{
			btValider.setDisable(false);
		}
		else
		{
			btValider.setDisable(true);
		}
	}
	
	
}

