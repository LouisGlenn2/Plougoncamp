package camping;

import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
/**
 * 
 * @author Marius Gaudin
 * 01/06/2019
 */
public class FenReservation extends Stage{
	private FenFormulaire f1 = new FenFormulaire();
	private VBox root = new VBox();
	private HBox contenu = new HBox();
	private VBox btControle = new VBox();
	private VBox menu = new VBox();
	private TableView<Reservation> listResa = new TableView<Reservation>();
	
	private Label labTitre = new Label("PlougonCamp");
	
	private Button bnAjouterResa = new Button("Ajouter une reservation ...");
	private Button bnDetailResa = new Button("Detail de la reservation ...");
	private Button bnSuppResa = new Button("Supprimer reservation");
	
	private Button bnFermer = new Button("Fermer");
	
	public FenReservation(){
		
		this.setTitle("Reservations");
		
		Scene laScene = new Scene(creerContenu());
		this.setScene(laScene);
		this.sizeToScene();
	}
		
	Parent creerContenu(){
		griserBoutons();
		labTitre.setFont(new Font("Arial", 30));	
		menu.setAlignment(Pos.CENTER);
		root.setAlignment(Pos.CENTER);
		root.setSpacing(20);
		root.setPadding(new Insets(10));
		contenu.setSpacing(100);
		btControle.setSpacing(20);
		menu.setSpacing(200);
		
		bnAjouterResa.setPrefWidth(250);
		bnDetailResa.setPrefWidth(250);
		bnSuppResa.setPrefWidth(250);
		bnFermer.setOnAction(e -> this.close());
		bnSuppResa.setOnAction(e -> supprimerReservation());
		
		root.setPadding(new Insets(20));
		listResa.setOnMouseClicked(e -> griserBoutons());
		root.setMaxHeight(900);
		bnAjouterResa.setOnAction(e -> Main.ouvrirFenAjouterReservation()); 
		bnDetailResa.setOnAction(e -> {Main.ouvrirFenDetailReservation(Main.getLesReservation().get(listResa.getSelectionModel().getSelectedIndex()));});
		btControle.getChildren().addAll(bnAjouterResa,bnDetailResa,bnSuppResa);
		menu.getChildren().addAll(btControle, bnFermer);
		contenu.getChildren().addAll(listResa, menu);
		root.getChildren().addAll(labTitre, contenu);
		return root;	
	}
	/**
	 * Permet de supprimer la reservation
	 */
	private void supprimerReservation() {
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.showAndWait().ifPresent(response -> {
		     if (response == ButtonType.OK) {
		    	Main.getReservation().remove(Main.getLesReservation().get(listResa.getSelectionModel().getSelectedIndex()));
		 		Main.getLesReservation().remove(listResa.getSelectionModel().getSelectedIndex());
		     }
		 });
		Main.sauvegarder();
		Main.getMenu().actualiserMap();
	}
	/**
	 * Permet de creer la table des reservation
	 */
	public void creerTable()
	{	
		for(int i=0;i<Main.getReservation().size();i++)
		{
			Main.getLesReservation().add(Main.getReservation().get(i));
		}
		
		
		listResa.setPrefSize(800, 700);
		/**
		 * creer les colonnes du tableau
		 */
		TableColumn<Reservation, String> numCol = new TableColumn<Reservation, String>("Numero de Reservation"); 
		TableColumn<Reservation, String> dateDeb = new TableColumn<Reservation, String>("Date de debut"); 
		TableColumn<Reservation, String> dateFin = new TableColumn<Reservation, String>("Date de fin");
		
		/**
		 * dimensions colonnes
		 */
		numCol.setMinWidth(200);
		dateDeb.setMinWidth(300);
		dateFin.setMinWidth(300);
		/**
		 * // definir les valeurs associe au colonnes
		 */
		numCol.setCellValueFactory( new PropertyValueFactory<Reservation, String>("numeroRes"));	
		dateDeb.setCellValueFactory(new PropertyValueFactory<Reservation, String>("date_Debut"));
		dateFin.setCellValueFactory(new PropertyValueFactory<Reservation, String>("date_Fin"));
	
		/**
		 * faire le lien entre les observableList (dans le main) et la tableView
		 */
		listResa.setItems(Main.getLesReservation()); 
		/**
		 * ajouter toutes les colonnes
		 */
		listResa.getColumns().addAll(numCol, dateDeb, dateFin); 
		
	}
	/**
	 * Permet d'actualiser la liste
	 */
	public void actualiserListe(ObservableList<Reservation> lesReservations) {
		if(listResa.getItems().size() == 0){
			griserBoutons();
		}
	}
	/**
	 * Permet de griser les boutons
	 */
	void griserBoutons(){
		if(listResa.getSelectionModel().getSelectedIndex() != -1){
			bnDetailResa.setDisable(false);
			bnSuppResa.setDisable(false);
		}else{
			bnDetailResa.setDisable(true);
			bnSuppResa.setDisable(true);
		}
	}
}
