package camping;

import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
/**
 * 
 * @author Antonin Dohollou
 * 01/06/2019
 */
public class FenRecapitulatifReservation extends Stage{
	private FenFormulaire fFormulaire;
	
	private Reservation reservation;
	private VBox root = new VBox();
	private VBox vbAdresse = new VBox();
	private VBox vbAdresseCamp = new VBox();
	private VBox vbAdresseCli = new VBox();
	private VBox vbDetails = new VBox();
	private HBox hbEmplacements = new HBox();
	private HBox hbMontant = new HBox();
	private HBox hbValMontant = new HBox();
	private HBox hbDetails = new HBox(); 
	private HBox hbButton = new HBox();
	
	private Label labPlougoncamp = new Label("CAMPING PLOUGONCAMP");
	private Label labAdresseCamping = new Label("Rue edouard Branly\r\n" + "22300 Lannion \r\n" + "Tel : 02 51 62 35 14");//entete du r�capitulatif
	
	private Label labFactureA = new Label("FACTURE  A");
	private Label labAdresseClient = new Label("");
	
	private Label labDetailsSejour = new Label("DETAILS SEJOUR ");
	private Label labDates = new Label("");
	
	private Label labEmplacement = new Label("");
	
	private Label labNb = new Label("NB");
	private Label labAge = new Label("AGE");
	private Label labMontant = new Label("MONTANT");
	
	private Label labValNb = new Label("");
	private Label labValAge = new Label("Adulte \nAdolescent \nEnfant");
	private Label labValMontant = new Label("");
	
	private Label labPrixInstallation = new Label("");
	private Label labTotal = new Label("");
	
	private Button btAjout = new Button("Confirmer");
	private Button btAnnuler = new Button("Annuler");
	private Button btPrecedent = new Button("Precedent");
	
	public FenRecapitulatifReservation()
	{
		this.setTitle("Plougoncamp");
		Scene laScene = new Scene(creerContenu());
		this.setScene(laScene);
		this.sizeToScene();
	}
	
	Parent creerContenu()
	{
		
		vbAdresseCamp.getChildren().addAll(labPlougoncamp, labAdresseCamping);
		vbAdresseCli.getChildren().addAll(labFactureA, labAdresseClient);
		
		vbAdresse.getChildren().addAll(vbAdresseCamp, vbAdresseCli);
		
		hbEmplacements.getChildren().addAll(labDates, labEmplacement);
		hbMontant.getChildren().addAll(labNb, labAge, labMontant);
		hbValMontant.getChildren().addAll(labValNb, labValAge, labValMontant);
		
		hbDetails.getChildren().addAll(labDetailsSejour);
		vbDetails.getChildren().addAll(hbDetails, hbEmplacements, hbMontant, hbValMontant, labPrixInstallation, labTotal);
		
		root.getChildren().addAll(vbAdresse, vbDetails, hbButton);
		
		vbAdresse.setSpacing(70);
		vbDetails.setSpacing(40);
		root.setSpacing(100);
		
		hbEmplacements.setSpacing(300);
		hbMontant.setSpacing(100);
		hbValMontant.setSpacing(100);
		
		root.setPadding(new Insets(20));
		
		labPlougoncamp.setFont(new Font("Arial", 15));
		labPlougoncamp.setStyle("-fx-font-weight: bold");
		
		labFactureA.setFont(new Font("Arial", 15));
		labFactureA.setStyle("-fx-font-weight: bold");
		
		labDetailsSejour.setFont(new Font("Arial", 15));
		labDetailsSejour.setStyle("-fx-font-weight: bold");
		
		labNb.setFont(new Font("Arial", 15));
		labNb.setStyle("-fx-font-weight: bold");
		
		labAge.setFont(new Font("Arial", 15));
		labAge.setStyle("-fx-font-weight: bold");
		
		labMontant.setFont(new Font("Arial", 15));
		labMontant.setStyle("-fx-font-weight: bold");
		
		labTotal.setFont(new Font("Arial", 15));
		labTotal.setStyle("-fx-font-weight: bold");
		
		labDates.setFont(new Font("Arial", 15));
		labEmplacement.setFont(new Font("Arial", 15));
		
		labValNb.setFont(new Font("Arial", 15));
		labValAge.setFont(new Font("Arial", 15));
		labValMontant.setFont(new Font("Arial", 15));
		
		hbMontant.setStyle("-fx-border-width: 1 0 1 0; -fx-border-color: black;");
		hbDetails.setStyle("-fx-border-width: 1 0 1 0; -fx-border-color: black;");
		
		hbButton.getChildren().addAll(btPrecedent, btAnnuler, btAjout);
		hbButton.setSpacing(50);
		/**
		 * /si le bouton precedents active alors ouvrir une fenetre de type formulaire 
		 */
		btPrecedent.setOnAction(e -> {Main.ouvrirUnefenetre(fFormulaire);this.close();});
		/**
		 * si le bouton Annuler alors mettre a zero la fenetre et fermer la fenetre
		 */
		btAnnuler.setOnAction(e -> {Main.zeroFenRes();this.close();});
		/**
		 *si le bouton ajout est active alors mettre a zero la fenetre et sauvegarder la page et la fermer apres
		 */
		btAjout.setOnAction(e -> {ajouterReservation();Main.zeroFenRes();Main.sauvegarder();this.close();});
		
		return root;
	}
	/**
	 * ecrire le recapitulatif de la reservation avec la page preconsus + les donnees 
	 * 
	 */
	public void setReservation(Reservation reserv)
	{
		this.reservation = reserv;
		labAdresseClient.setText(reservation.getClientPrincipal().getNom()+" "+reservation.getClientPrincipal().getPrenom()+
								 "\n"+reservation.getClientPrincipal().getAdresse()+ 
				   				 "\n"+reservation.getClientPrincipal().getCode_postal()+" "+reservation.getClientPrincipal().getVille());
		
		labDates.setText("Du "+reservation.getDate_Debut()+
						"\nAu "+reservation.getDate_Fin()+
						"\n("+reservation.getNbJours()+" Jours)");
		
		labEmplacement.setText("Numero d emplacement : "+reservation.getEmplacement().getNumeroEmp()+
				 			   "\nType d emplacement : "+reservation.getEmplacement().getTypeEmplacement());
		
		labValNb.setText(reservation.getNbAdulte()+"\n"+reservation.getNbAdo()+"\n"+reservation.getNbEnfant());
		labValMontant.setText(reservation.getPrixAdulte()+"\n"+reservation.getPrixAdo()+"\n"+reservation.getPrixEnfant());
		
		labTotal.setText("TOTAL : "+reservation.getTarif()+" euros");
		
		if(reserv.getEmplacement().getTypeEmplacement().equals("MobilHome"))
		{
			labPrixInstallation.setText("+ Prix MobilHome("+reserv.getEmplacement().getNbPlaces()+" places) : "+reserv.getEmplacement().getTarif());
		}
		else
		{
			TerrainNu terrNu = (TerrainNu) reserv.getEmplacement();
			labPrixInstallation.setText("+ Taxes ("+terrNu.getTypeInstalation()+") : "+terrNu.getTarif());
			
		}
		
	}
	
	public void setFormulaire(FenFormulaire f)
	{
		this.fFormulaire = f;
	}
	/**
	 * ajouter la reservation a la liste des reservation en appelant des methodes dans la class main
	 */
	public void ajouterReservation()
	{
		Main.getLesReservation().add(reservation);
		Main.getReservation().add(reservation);
		while(!Main.getLesEmplacements().isEmpty())
		{
			Main.getLesEmplacements().remove(0);
		}
		Main.getMenu().actualiserMap();
	}

}
