package camping;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
/**
 * 
 * @author Baron Emile, Louis Glenn
 * 15/05/19
 */
public class Reservation implements Serializable {

	private static final long serialVersionUID = -768253898332788644L;
	/**
	 * Constante a fin d'imposer une taxe en fonction de l'age des clients,(ici pour un mobilhome)
	 */
	private final static double MOBILHOME_ADULTE = 10; 
	private final static double MOBILHOME_ADO = 8;	   
	private final static double MOBILHOME_ENFANT = 5;  
	/**
	 * Constante a fin d'imposer une taxe en fonction de de l'age des clients,(ici pour un terrain nu)
	 */
	private final static double TERRAIN_NU_ADULTE = 6; 
	private final static double TERRAIN_NU_ADO = 4;    
	private final static double TERRAIN_NU_ENFANT = 2; 
	
	private Emplacement emplacement;
	private LocalDate date_Debut;
	private LocalDate date_Fin;
	private long nbJours;
	private double tarif = 0;
	private int numeroRes;
	/**
	 * Obligation d'au moins 1 adulte
	 * Mise a 0 du compte de nbAdo
	 * Mise a 0 du compte de nbEnfant
	 */
	private int nbAdulte = 1; 
	private int nbAdo = 0;	  
	private int nbEnfant = 0; 
	/**
	 * Mise a 0 des prix
	 */
	private double prixAdulte = 0; 
	private double prixAdo = 0;    
	private double prixEnfant = 0;
	
	private static int nbRes = 0;
	private Client clientPrincipal;
	/**
	 * liste contenant l'ensemble des clients de la reservation
	 */
	private ArrayList<ClientSec> listePer;
	private int nbP;
	
	public Reservation(Emplacement e, int nbP, LocalDate dateDebut, LocalDate dateFin, Client cliPrincipal, ArrayList<ClientSec> listePer) {
		this.date_Debut = dateDebut;
		this.date_Fin = dateFin;
		this.numeroRes = nbRes;
		nbRes++;
		this.clientPrincipal = cliPrincipal;
		this.emplacement = e;
		this.nbP = nbP;
		this.listePer = listePer;
		/**
		 * Permet de calculer le nombre de jour entre date_Debut et date_Fin
		 */
		this.nbJours = ChronoUnit.DAYS.between(date_Debut, date_Fin);
		
	}
	
	public void setEmplacement(Emplacement e)
	{
		this.emplacement = e;
	}
	
	public int getNumeroRes()
	{
		return this.numeroRes;
	}
	
	public Client getClientPrincipal()
	{
		return this.clientPrincipal;
	}
	
	public long getNbJours()
	{
		return nbJours;
	}
	
	
	public int getNbAdulte()
	{
		return nbAdulte;
	}
	
	public int getNbAdo()
	{
		return nbAdo;
	}
	
	public int getNbEnfant()
	{
		return nbEnfant;
	}
	
	public double getPrixAdulte()
	{
		return prixAdulte;
	}
	
	public double getPrixAdo()
	{
		return prixAdo;
	}
	
	public double getPrixEnfant()
	{
		return prixEnfant;
	}
	
	public Emplacement getEmplacement() {
		return this.emplacement;
	}

	public LocalDate getDate_Debut() {
		return this.date_Debut;
	}

	public LocalDate getDate_Fin() {
		return this.date_Fin;
	}

	public double getTarif() {
		return this.tarif;
	}
	/**
	 * ajoute une personne a la liste de la reservation
	 * si la liste n'est pas pleine alors
	 * pour tout i de 0 a fin de la liste faire
	 * si le client n'existe pas deja dans la liste alors
	 * ajouter le client a la liste
	 * sinon
	 * afficher message d'erreur
	 */
	public void ajouterPers(ClientSec c) {							
		if(listePer.size() < nbP) {									
			for(int i=0;i<this.listePer.size();i++) {				
				if(listePer.get(i).getPrenom() ==  c.getPrenom()) { 
					listePer.add(c);								
				}else {												
					System.out.println("Personne deja ajoute !");	
				}
			}
			
		}
	}
	/**
	 * Si l'emplacement est un terrain nu alors tarif += TERRAIN_NU_ADULTE
	 * Sinon alors tarif += TERRAIN_NU_ADULTE
	 */
	public void calculPrix(){
		if(emplacement.getTypeEmplacement().equals("Terrain Nu")) { 
			tarif+=TERRAIN_NU_ADULTE;
		}else{														
			tarif+=MOBILHOME_ADULTE;
		}
		
		nbAdulte = 1;
		/**
		 * calcul nbEnfant, nbAdulte, nbAdo present dans la liste clients
		 */
		for(int i=0;i<nbP-1;i++) { 
			if(listePer.get(i).getAge().equals("Adulte (+18ans)")){
				nbAdulte += 1;
			}
			else if(listePer.get(i).getAge().equals("Adolescent (11-18ans)")){
				nbAdo += 1;
			}else{
				nbEnfant += 1;
			}
		}
		/**
		 * calcul du tarif total en fonction du type d'emplacement reserve
		 */
		if(emplacement.getTypeEmplacement().equals("Terrain Nu")){ 
			prixAdulte += nbAdulte*TERRAIN_NU_ADULTE*nbJours;
			prixAdo += nbAdo*TERRAIN_NU_ADO*nbJours;
			prixEnfant += nbEnfant*TERRAIN_NU_ENFANT*nbJours;
		}else{
			prixAdulte += nbAdulte*MOBILHOME_ADULTE*nbJours;
			prixAdo += nbAdo*MOBILHOME_ADO*nbJours;
			prixEnfant += nbEnfant*MOBILHOME_ENFANT*nbJours;
		}	
		tarif = prixAdulte+prixAdo+prixEnfant+emplacement.getTarif();	
	}

}
