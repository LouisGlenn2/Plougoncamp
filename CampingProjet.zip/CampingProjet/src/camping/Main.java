package camping;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.SelectionMode;
import javafx.stage.Modality;
import javafx.stage.Stage;
/***
 * 
 * @author Marius Gaudin, Antonin Dohollou, Emilie Baron, Glenn Louis
 * 01/06/2019
 */
public class Main extends Application{
	
	public final static int NB_MOBILHOME = 39; 
	public final static int NB_TERRAIN_NU = 27;
	public final static String FIC_EMPLACEMENT = "Emplacement.txt";
	public final static String FIC_RESERVATION = "Reservation.txt";
	
	static private ArrayList<Reservation> tabReservation = new ArrayList<Reservation>(); 
	static private ArrayList<Emplacement> tabEmplacement = new ArrayList<Emplacement>(); 
	
	static private FenMenu fMenu = new FenMenu();
	static private FenReservation fReservation = new FenReservation();
	/**
	 * detail reservation
	 */
	static private FenDetailsResa fDetailResa = new FenDetailsResa();
	static private FenRecapitulatifReservation fRecapReservation = new FenRecapitulatifReservation();
	/**
	 * detail reservation
	 */
	static private FenAjouterReservation fAjouResa = new FenAjouterReservation();
	static private FenFormulaire fFormulaire = new FenFormulaire();
	
	static private ObservableList<Reservation> lesReservations = FXCollections.observableArrayList();
	static private ObservableList<Emplacement> lesEmplacements = FXCollections.observableArrayList();
	
	public void start(Stage primaryStage) throws Exception {
		
		Sauvegarde sauv = new Sauvegarde();
		tabEmplacement = sauv.RecupererEmplacement(Main.FIC_EMPLACEMENT);
		tabReservation = sauv.RecupererReservation(Main.FIC_RESERVATION);
		
		fAjouResa.creerTable();
		fReservation.creerTable();
		
		fMenu.initMap();
		fMenu.actualiserMap();
		
		fMenu.show();
	}
	
	public static ArrayList<Reservation> getReservation(){
		return tabReservation;
	}
	
	public static ObservableList<Reservation> getLesReservation(){
		return lesReservations;
	}
	
	public static ArrayList<Emplacement> getEmplacement()
	{
		return tabEmplacement;
	}
	
	public static ObservableList<Emplacement> getLesEmplacements()
	{
		return lesEmplacements;
	}
	
	public static FenMenu getMenu()
	{
		return fMenu;
	}

	/////////////////////////////////////////////////////
	// Gestion des fenetres
	/////////////////////////////////////////////////////

	static public void ouvrirFenReservation(){ 
		// initialiser l'etat de la fenetre
		fReservation.actualiserListe(Main.lesReservations);	
		// ...avant de l'afficher
		fReservation.show();
	}
	
	static public void ouvrirFenAjouterReservation(){ 
		// initialiser l'etat de la fenetre
	
		
		// ...avant de l'afficher
		fAjouResa.show();
	}
	
	static public void ouvrirFenDetailReservation(Reservation reservation){ 
		// initialiser l'etat de la fenetre
		fDetailResa.setReservation(reservation);
		// ...avant de l'afficher
		fDetailResa.show();
	}
	
	static public void ouvrirFenRecapitulatifReservation(Reservation reserv, FenFormulaire f)
	{ 
		fRecapReservation.setReservation(reserv);
		fRecapReservation.setFormulaire(f);
		fRecapReservation.show();
	}
	
	
	static public void ouvrirFenEmplacementDetails(Emplacement emp)
	{
		FenEmplacementDetails fEmpDetails = new FenEmplacementDetails(emp);
		fEmpDetails.show();
	}

	static public void ouvrirFenFormulaire()
	{
		
		fFormulaire.setFormulaire(fAjouResa.getNbPersonne(),fAjouResa.getDateDebut(),fAjouResa.getDateFin(),fAjouResa.getEmplacement());
		
		fFormulaire.show();
	}
	
	static public void ouvrirUnefenetre(Stage fen)
	{
		fen.show();
	}
	
	/**
	 * mise a zero des Fenetres de reservations
	 */
	static public void zeroFenRes()
	{
		fAjouResa = new FenAjouterReservation();
		fAjouResa.creerTable();
		
		fFormulaire = new FenFormulaire();
	}
	
	public static void main(String[] args) { 				
		Application.launch(args); 
	}	
	
	public static void sauvegarder()
	{
		Sauvegarde sauv = new Sauvegarde();
		sauv.sauverEmplacement(Main.getEmplacement(), Main.FIC_EMPLACEMENT);
		sauv.sauverReservation(Main.getReservation(), Main.FIC_RESERVATION);
	}
	
}