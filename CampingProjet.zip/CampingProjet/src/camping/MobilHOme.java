package camping;
/**
 * 
 * @author Emilie Baron
 * 17/05/19
 */
public class MobilHOme extends Emplacement{

	private double tarif;
	private final static double TARIF4 = 250.0;//
	private final static double TARIF6 = 375.0;//Tarif selon le nombre de personne
	private final static double TARIF8 = 550.0;//
	private int nbP;
	
	public MobilHOme(String lib, int nbP) {
		super(lib, "MobilHome", nbP);
		if(nbP == 4)
		{
			tarif = TARIF4;
		}
		else if(nbP == 6)
		{
			tarif = TARIF6;
		}
		else
		{
			tarif = TARIF8;
		}
		this.nbP = nbP;
	}

	public double getTarif() {
		return tarif;
	}

}
