package camping;

import java.io.Serializable;
/**
 * 
 * @author Glenn Louis
 * 17/05/19
 */
public abstract class Emplacement implements Serializable {

	private static final long serialVersionUID = 8499331577864563544L;
	private String typeEmplacement;
	private String libelle;
	private String raison;
	private Reservation resa;
	private int numeroEmp;
	private boolean disponibilite;
	/**
	 * creation d'un numero pour incrementer de 1 le numero client a chaque creation de nouveau client
	 */
	private static int i = 0;
	private int nbPlaces;
	
	public Emplacement(String lib, String type, int nbp) {
		this.libelle = lib;
		this.disponibilite = true;
		this.typeEmplacement = type;
		this.nbPlaces = nbp;
		this.numeroEmp = i;
		i++;
	
	}
	
	abstract double getTarif();
	
	public String getTypeEmplacement()
	{
		return this.typeEmplacement;
	}
	
	public int getNbPlaces()
	{
		return this.nbPlaces;
	}

	public String getLibelle() {
		return this.libelle;
	}

	public String getRaison() {
		return this.raison;
	}

	public int getNumeroEmp() {
		return this.numeroEmp;
	}

	public boolean getDisponibilite() {
		return this.disponibilite;
	}
	
	public Reservation getReservation()
	{
		return this.resa;
	}
	
	public void setReservation(Reservation s)
	{
		this.resa = s;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public void setRaison(String raison) {
		this.raison = raison;
	}

	public void setDisponibilite(boolean disponibilite) {
		this.disponibilite = disponibilite;
	}
}
