package camping;

import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
/**
 * 
 * @author Emilie Baron
 * 01/06/19
 */
public class FenEmplacementDetails extends Stage{
	
	private Emplacement emp;
	private Label num;
	private Label type;
	private Label client;
	private Label dateDeb = new Label("");
	private Label dateFin = new Label("");
	
	private VBox root = new VBox();
	private BorderPane btn = new BorderPane();
	
	private Button bnFermer = new Button("Fermer");
	
	public FenEmplacementDetails(Emplacement e)
	{
		this.emp = e;
		this.num = new Label("Numero : "+this.emp.getNumeroEmp());
		this.type = new Label("Type : "+this.emp.getTypeEmplacement());
		if(emp.getDisponibilite())						
		{
			this.client = new Label("Est disponible");  
		}
		else											
		{
			/**
			 * Ecrire le nom du client principale de la reservation
			 * Ecrire la date de debut
			 * Ecrire la date de fin
			 */
			this.client = new Label("Client : "+emp.getReservation().getClientPrincipal()); 
			this.dateDeb.setText("Du "+emp.getReservation().getDate_Debut());				
			this.dateFin.setText("Au "+emp.getReservation().getDate_Fin());					
		}
		
		
		this.setTitle(emp.getLibelle()); 
		this.setResizable(false);
		Scene laScene = new Scene(creerContenu());
		this.setScene(laScene);
		this.sizeToScene();
	}
	
	Parent creerContenu()
	{
		btn.setRight(bnFermer);
		
		bnFermer.setOnAction(e -> close());
		
		root.getChildren().addAll(num, type, client, dateDeb, dateFin, btn);
		root.setPadding(new Insets(10));
		root.setSpacing(5);
		return root;
	}
}
