package camping;
/**
 * 
/* * @author Glenn Louis
 * 17/05/19
 */
import java.io.Serializable;

public class Client implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5510156650557048690L;
	private String nom;
	private String prenom;
	private int numCli;
	private String adresse;
	private String ville;
	private String code_postal;
	/**
	 * creation d'un numero pour incrementer de 1 le numero client a chaque creation de nouveau client
	 */
	private static int num = 1;

	
	public Client(String nom, String prenom, String ville , String adresse, String code_postal) {
		this.nom = nom;
		this.prenom = prenom;
		this.adresse = adresse;
		this.code_postal = code_postal;
		this.numCli = num;
		this.ville = ville;
		num++;
	}
	
	public String getVille()
	{
		return this.ville;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	public String getCode_postal() {
		return code_postal;
	}

	public void setCode_postal(String code_postal) {
		this.code_postal = code_postal;
	}
}