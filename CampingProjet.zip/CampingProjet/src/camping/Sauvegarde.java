package camping;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.LinkedList;
/**
 * 
 * @author Louis Glenn, Marius Gaudin, Dohollou Antonin
 * 19/06/2019
 */
public class Sauvegarde {
	
	public Sauvegarde()
	{
	
	}
	
	public void sauverEmplacement(ArrayList<Emplacement> emp, String nomFic)//Permet de sauvegarder les emplacements
	{
		ObjectOutputStream fichier_ecriture;
		LinkedList<Emplacement> listDonnees = new LinkedList<Emplacement>();
		
		for(int i=0;i<emp.size();i++)
		{
			listDonnees.add(emp.get(i));
		}
		
		
		try 
		{
			fichier_ecriture = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(new File(nomFic))));
			
			fichier_ecriture.writeObject(listDonnees);
			
			fichier_ecriture.close();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e) 
		{ 
			e.printStackTrace();
	    } 
		
	}
	
	public void sauverReservation(ArrayList<Reservation> resa, String nomFic)//Permet de sauvegarder les reservation
	{
		ObjectOutputStream fichier_ecriture;
		LinkedList<Reservation> listDonnees = new LinkedList<Reservation>();
		
		for(int i=0;i<resa.size();i++)
		{
			listDonnees.add(resa.get(i));
		}
		
		
		try 
		{
			fichier_ecriture = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(new File(nomFic))));
			
			fichier_ecriture.writeObject(listDonnees);
			
			fichier_ecriture.close();
		}
		catch(FileNotFoundException e)
		{
			 e.printStackTrace();
		}
		catch (IOException e) 
		{ 
	      e.printStackTrace();
	    } 
		
	}
	
	public ArrayList<Emplacement> RecupererEmplacement(String nomFic)//Permet de recupere la sauvegarde les emplacements
	{
		ObjectInputStream fichier_lecture;
		LinkedList<Emplacement> objet = null;
		
		try
		{
			fichier_lecture = new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File(nomFic))));
			
			try
			{
				objet = ( LinkedList<Emplacement>)(fichier_lecture.readObject());
			}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			
			fichier_lecture.close();
			
			
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		} 
		catch (IOException e) {

			e.printStackTrace();
		}
		
		ArrayList<Emplacement> tabEmp = new ArrayList<Emplacement>(); 
		
        for(int i=0; i< objet.size();i++)
        {
        	tabEmp.add(objet.get(i));
        }
		
        return tabEmp;
	}
	
	public ArrayList<Reservation> RecupererReservation(String nomFic)//Permet de recupere la sauvegarde les reservation
	{
		ObjectInputStream fichier_lecture;
		LinkedList<Reservation> objet = null;
		
		try
		{
			fichier_lecture = new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File(nomFic))));
			
			try
			{
				objet = ( LinkedList<Reservation>)(fichier_lecture.readObject());
			}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			
			fichier_lecture.close();
			
			
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		} 
		catch (IOException e) {

			e.printStackTrace();
		}
		
		ArrayList<Reservation> tabResa = new ArrayList<Reservation>(); 
		
        for(int i=0; i< objet.size();i++)
        {
        	tabResa.add(objet.get(i));
        }
		
        return tabResa;
	}


}
