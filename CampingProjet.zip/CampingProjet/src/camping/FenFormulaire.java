package camping;
/**
 * 
 * @author Marius Gaudin
 *
 */
import java.time.LocalDate;
import java.util.ArrayList;

import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class FenFormulaire extends Stage{
	
	private FlowPane root = new FlowPane();
	private HBox client = new HBox(); 
	private VBox hbLab = new VBox(); 
	private VBox hbTextField = new VBox();
	private VBox vbPersonne = new VBox();
	
	private Button btValider = new Button("Suivant");
	
	private Label labNom = new Label("Nom");
	private TextField chxNom = new TextField();
	
	
	private ComboBox<String> chxTerrainNu = new ComboBox<String>();
	
	private Label labPrenom = new Label("Prenom");
	private TextField chxPrenom = new TextField();
	
	private Label labVille = new Label("Ville");
	private TextField chxVille = new TextField();
	
	private Label labCodePostal = new Label("Code postal");
	private TextField chxCodePostal = new TextField();
	
	private Label labAdresse = new Label("Adresse");
	private TextField chxAdresse = new TextField();
	
	private Label labPersonne1 = new Label("Personne n�1");
	
	private int nbFormulaire;
	
	private TextField listNom[];
	private TextField listPrenom[];
	private ComboBox listAge[];
	
	private LocalDate dateDebut;
	private LocalDate dateFin;
	private Emplacement empl;
	
	public FenFormulaire()
	{

		
		this.setTitle("Plougoncamp");
		
		Scene laScene = new Scene(creerContenu());
		this.setScene(laScene);
		this.sizeToScene();
	}
	
	Parent creerContenu()
	{
		/**
		 * desactiver le bouton
		 */
		griserSuivant(); 
		
		chxTerrainNu.getItems().addAll("Caravane","Camping-car","Tente");
		chxNom.textProperty().addListener(e -> griserSuivant());
		chxPrenom.textProperty().addListener(e -> griserSuivant());
		chxVille.textProperty().addListener(e -> griserSuivant());
		chxCodePostal.textProperty().addListener(e -> griserSuivant());
		chxAdresse.textProperty().addListener(e -> griserSuivant());
		
		hbLab.getChildren().addAll(labNom, labPrenom, labVille, labCodePostal, labAdresse);
		hbTextField.getChildren().addAll(chxNom, chxPrenom, chxVille, chxCodePostal, chxAdresse, chxTerrainNu);
		client.getChildren().addAll(hbLab, hbTextField);
		labPersonne1.setFont(new Font("Arial", 20));
		vbPersonne.getChildren().addAll(labPersonne1, client);
		vbPersonne.setStyle("-fx-border-width: 1;" + "-fx-border-color: black;");
		vbPersonne.setMaxWidth(400);
		vbPersonne.setPadding(new Insets(10));
		vbPersonne.setSpacing(10);
		vbPersonne.setMinHeight(565);
		root.getChildren().add(vbPersonne);
		
		root.setOrientation(Orientation.VERTICAL);
		
		hbLab.setSpacing(20);
		hbTextField.setSpacing(10);
		client.setSpacing(50);
		
		root.setHgap(50);
		root.setVgap(30);
		root.setPadding(new Insets(20));
		
		btValider.setOnAction(e -> ajouterReservation());
		return root;
	}
	/**
	 * Initialise le formulaire en forme avant d'ouvrir la fenetre
	 */
	public void setFormulaire(int nbPerson, LocalDate dDebut, LocalDate dFin, Emplacement e)
	{
		this.nbFormulaire = nbPerson-1;
		this.listNom = new TextField[this.nbFormulaire];
		this.listPrenom= new TextField[this.nbFormulaire];
		this.listAge = new ComboBox[this.nbFormulaire];
		
		this.dateDebut = dDebut;
		this.dateFin = dFin;
		this.empl = e;
		
		if(e.getTypeEmplacement().equals("MobilHome"))
		{
			chxTerrainNu.setVisible(false);
		}
		else
		{
			chxTerrainNu.setVisible(true);
			chxTerrainNu.setOnAction(ex -> griserSuivant());
		}

		for(int i=0;i<this.nbFormulaire;i++)
		{
			VBox vbLabClient = new VBox();
			VBox vbTextFieldClient = new VBox();
			HBox hbContenu = new HBox();
			VBox vbPersonne = new VBox();
			
			Label labPersonne = new Label("Personne numero "+(i+2));
			labPersonne.setFont(new Font("Arial", 20));
			
			Label labNom = new Label("Nom");
			Label labPrenom = new Label("Prenom");
			Label labAge = new Label("Age");
			
			vbLabClient.getChildren().addAll(labNom,labPrenom,labAge);
			vbLabClient.setSpacing(20);
			
			TextField textNom= new TextField();
			listNom[i] = textNom;
			listNom[i].textProperty().addListener(exp -> griserSuivant());
			
			TextField textPrenom= new TextField();
			listPrenom[i] = textPrenom;
			listPrenom[i].textProperty().addListener(exp -> griserSuivant());
			ComboBox<String> chxAge = new ComboBox<String>();
			listAge[i] = chxAge;
			listAge[i].setOnAction(exp -> griserSuivant());
			listAge[i].getItems().addAll("Enfant (-11ans)", "Adolescent (11-18ans)", "Adulte (+18ans)");
			
			vbTextFieldClient.getChildren().addAll(listNom[i],listPrenom[i],listAge[i]);
			vbTextFieldClient.setSpacing(10);
			
			hbContenu.getChildren().addAll(vbLabClient, vbTextFieldClient);
			hbContenu.setSpacing(50);
			
			vbPersonne.getChildren().addAll(labPersonne, hbContenu);
			vbPersonne.setSpacing(10);
			vbPersonne.setStyle("-fx-border-width: 1;" + "-fx-border-color: black;");
			vbPersonne.setMaxWidth(400);
			vbPersonne.setPadding(new Insets(10));
			
			root.getChildren().add(vbPersonne);
			
		}
		
		root.getChildren().add(btValider);
		
	}
	/**
	 * Permet d'ajouter une reservation lorsque l'on appuie sur le bouton bnValider
	 */
	public void ajouterReservation()
	{
		Client cli = new Client(chxNom.getText(), chxPrenom.getText(), chxVille.getText(), chxAdresse.getText(), chxCodePostal.getText());
		ArrayList<ClientSec> listePerSec = new ArrayList<ClientSec>();
		if(nbFormulaire != 0)
		{
			for(int i=0;i<nbFormulaire;i++)
			{
				ClientSec cliSec = new ClientSec(listNom[i].getText(), listPrenom[i].getText(), listAge[i].getValue().toString());
				listePerSec.add(cliSec);
			}
		}
		
		Reservation reserv = new Reservation(empl, nbFormulaire+1, dateDebut, dateFin, cli, listePerSec);
		
		if(empl.getTypeEmplacement().equals("Terrain Nu"))
		{
			((TerrainNu)reserv.getEmplacement()).setTarif(chxTerrainNu.getValue());
		}
		
		reserv.calculPrix();
		
		Main.ouvrirFenRecapitulatifReservation(reserv, this);
		this.close();
	}
	/**
	 * Permet de griser le bouton si les textfield non pas tous etaient remplit
	 */
	public void griserSuivant()
	{
		if(chxNom.getText().isEmpty() || chxPrenom.getText().isEmpty() || chxVille.getText().isEmpty() || chxCodePostal.getText().isEmpty() || chxAdresse.getText().isEmpty())
		{
			btValider.setDisable(true);
		}
		else
		{
			boolean rempli = true;
			int i =0;
			while(i<nbFormulaire && rempli)
			{
				if(listNom[i].getText().isEmpty() || listPrenom[i].getText().isEmpty() || listAge[i].getSelectionModel().getSelectedIndex() == -1)
				{
					rempli = false;
				}
				else
				{
					rempli = true;
				}
				i++;
			}
			
			if(rempli)
			{
				btValider.setDisable(false);
			}
			else
			{
				btValider.setDisable(true);
			}
		}
	}

}
