package camping;

import java.io.InputStream;
import java.time.LocalDate;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.stage.Stage;
/**
 * 
 * @author Antonin DOHOLLOU
 *01/06/19
 */
public class FenMenu extends Stage{
	/**
	 * longueur de la grille
	 * largeur de la grille
	 */
	final static int LONGUEUR = 22;
	final static int LARGEUR = 16; 
	
	private HBox contenu = new HBox();
	private VBox root = new VBox();
	private GridPane grid = new GridPane();
	private VBox carte = new VBox();
	private VBox menu = new VBox();
	private Label titre = new Label("Plougoncamp");
	private DatePicker date = new DatePicker(); 
	private Button btAjouterRes = new Button("Voir R�servations...");
	private Button bnQuitter = new Button("Quitter"); 
	
	private Button emplacements[][] = new Button[LONGUEUR][LARGEUR];
	/**
	 * case contenant la mer
	 */
	private int mer[] = {12,13,13,13,13,13,13,13,13,13,13,14,14,15,15,14,13,13,13,13,12,12};
	/**
	 * case contenant la place
	 */
	private int plage[] = {11,11,11,11,11,11,11,12,12,12,12,12,12,12,12,12,11,11,11,10,10,10};
	/**
	 * case contenant les emplacements
	 */
	private int posEmplacements[][] = {{2,0},{2,2},{3,0},{3,3},{4,0},{4,2},{5,0},{5,2},{7,0},{7,2},{8,0},{8,2},{9,0},{9,2},{5,3},{7,3},{3,5},{4,4},{4,6},
			{5,4},{5,6},{7,4},{7,6},{8,4},{8,6},{9,4},{9,6},{10,5},{5,7},{7,7},{5,8},{7,8},{5,9},{8,8},{8,10},{9,8},{9,10},{10,8},{10,10},{8,11},{8,12},
			{7,14},{9,13},{8,15},{9,15},{5,14},{5,15},{7,15},{5,16},{7,16},{3,18},{4,17},{4,19},{5,17},{5,19},{7,17},{7,19},{8,17},{8,19},{9,18},{4,20},
			{5,20},{7,21},{8,21},{9,21},{9,19}};  
                                          
	public FenMenu()
	{
		this.setTitle("Plougoncamp"); 
		this.setResizable(false);
		Scene laScene = new Scene(creerContenu());
		this.setScene(laScene);
		this.sizeToScene();
	}
	
	Parent creerContenu()
	{
	
		/**
		 * Creation de la map + Mer + Plage + route
		 */
		
		
		for(int i=0;i<LONGUEUR;i++)
		{
			for(int j=0;j<LARGEUR;j++)
			{
				emplacements[i][j] = new Button(" ");
				
				emplacements[i][j].setPrefHeight(47);
				emplacements[i][j].setPrefWidth(47);
				
				grid.add(emplacements[i][j], i, j);
				
				emplacements[i][j].setStyle("-fx-border-color: black");
				if((i==1 && j>=2 && j<=10)||(i==2 && j==3)||(j==6 && i<=9)||(i==5 && j>=4 && j<=9)||(i==9 && j>=6 && j<=11)||(i>=10 && i<=12 && j==7)
						||(i==13 && j>=5 && j<=8)||(i>=14 && j==6)||(i==18 && j>=4 && j<=8)||(i==20 && j>=7 && j<=9)||(i==21 && j>=4 && j<=6))
				{
					emplacements[i][j].setStyle("-fx-background-color:  #c2c2c2; -fx-border-color: black");
				}
				else if(j >= mer[i])
				{
					emplacements[i][j].setStyle("-fx-background-color:  #5f5ff0; -fx-border-color: black");
				}
				else if(j >= plage[i])
				{
					emplacements[i][j].setStyle("-fx-background-color:  #e3ea6f; -fx-border-color: black");
				}
				else
				{
					emplacements[i][j].setStyle("-fx-background-color:  #e5e5e5; -fx-border-color: black");
				}
				
			}
		}
		/**
		 * ajout du logo du camping
		 */
		InputStream input = this.getClass().getResourceAsStream("/images/logo.png");
		Image imgLogo = new Image(input, 130, 130, false, true);
		ImageView logo = new ImageView(imgLogo);
		
		logo.setTranslateX(50);
		/**
		 * ajout de la legende de la map
		 */
		InputStream input2 = this.getClass().getResourceAsStream("/images/legende.png");
		Image imgLegende = new Image(input2, 375, 93, false, true);
		ImageView legende = new ImageView(imgLegende);
		 /**
		  * en fonction de la date choisie actualiser la map
		  */
		date.valueProperty().addListener(e -> this.actualiserMap());
		/**
		 * si bouton ajouter active ouvrir la fenetre reservation
		 */
		btAjouterRes.setOnAction(e -> Main.ouvrirFenReservation());
				
		btAjouterRes.setPrefHeight(50);
		btAjouterRes.setPrefWidth(250);
	
		titre.setFont(new Font("Arial", 30));
		
		date.setValue(LocalDate.now());
		
		root.setSpacing(20);
		root.setPadding(new Insets(10));
		root.setAlignment(Pos.CENTER);
		carte.getChildren().addAll(date, grid, legende);
		carte.setSpacing(10);
		menu.getChildren().addAll(logo, btAjouterRes, bnQuitter);
		contenu.getChildren().addAll(menu, carte);
		contenu.setSpacing(100);
		/**
		 * si bouton sauvegarder active alors sauvegarder toutes les actions faite depuis l'ouverture et fermer le logiciel
		 */
		bnQuitter.setOnAction(e -> {Main.sauvegarder(); System.exit(0);});
		bnQuitter.setPrefWidth(125);
		bnQuitter.setPrefHeight(50);
		
		menu.setPadding(new Insets(40));
		menu.setSpacing(300);
		root.getChildren().addAll(titre, contenu);
		return root;
	}
	/**
	 * actualisation de la map en fonction de la date choisie
	 */
	public void actualiserMap()
	{
		for(int i=0;i<(Main.NB_MOBILHOME+Main.NB_TERRAIN_NU);i++)
		{
			emplacements[posEmplacements[i][1]][posEmplacements[i][0]].setStyle("-fx-background-color: #31ca00; -fx-border-color: black");
		}
		
		for(int i=0;i<Main.getReservation().size();i++)
		{
			int j = Main.getReservation().get(i).getEmplacement().getNumeroEmp();
			
			if(Main.getReservation().get(i).getDate_Debut().compareTo(date.getValue())<=0 && Main.getReservation().get(i).getDate_Fin().compareTo(date.getValue())>=0)
			{
				emplacements[posEmplacements[j][1]][posEmplacements[j][0]].setStyle("-fx-background-color: red; -fx-border-color: black");
				Main.getEmplacement().get(j).setDisponibilite(false);
				Main.getEmplacement().get(j).setReservation(Main.getReservation().get(i));
			}
			else
			{
				emplacements[posEmplacements[j][1]][posEmplacements[j][0]].setStyle("-fx-background-color: #31ca00; -fx-border-color: black");
				Main.getEmplacement().get(j).setDisponibilite(true);
			}
		}
		
	}
	/**
	 * initialisation de la map lors de l'ouverture du logiciel
	 */
	public void initMap()
	{
		for(int i=0;i<(Main.NB_MOBILHOME+Main.NB_TERRAIN_NU);i++)
		{
			Emplacement emp = Main.getEmplacement().get(i);
			if(emp.getClass().getName().contentEquals(MobilHOme.class.getName()))
			{
				emplacements[posEmplacements[i][1]][posEmplacements[i][0]].setGraphic(new Circle(0, 0, 2, Color.BLACK));	
			}
		
			emplacements[posEmplacements[i][1]][posEmplacements[i][0]].setText(""+i);
			Main.getEmplacement().get(i).setDisponibilite(true);
			emplacements[posEmplacements[i][1]][posEmplacements[i][0]].setStyle("-fx-background-color:     #31ca00; -fx-border-color: black");
			emplacements[posEmplacements[i][1]][posEmplacements[i][0]].setOnAction(e -> {Main.ouvrirFenEmplacementDetails(emp);});
		}
	}
	
}
