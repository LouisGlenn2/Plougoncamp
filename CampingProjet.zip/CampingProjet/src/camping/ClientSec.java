package camping;

import java.io.Serializable;
/**
 * 
 * @author Glenn Louis
 * 17/05/19
 */
public class ClientSec implements Serializable {
	private static final long serialVersionUID = 8407201784580054944L;
	private String nom;
	private String prenom;
	private String age;
	
	public ClientSec(String n, String p, String a)
	{
		this.nom = n;
		this.prenom = p;
		this.age = a;
	}
	
	public String getNom()
	{
		return this.nom;
	}
	
	public String getPrenom()
	{
		return this.prenom;
	}
	
	public String getAge()
	{
		return this.age;
	}
	
}
