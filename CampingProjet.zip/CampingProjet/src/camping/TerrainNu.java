package camping;
/**
 * 
 * @author Antonin Dohollou
 * 17/05/19
 */
public class TerrainNu extends Emplacement{
	
	private final static int NBPLACE = 10;//variable static � fin de limiter le nombre de personne sur ce type d'emplacement
	private final static double CARAVANE = 0.30;  //
	private final static double CAMPINGCAR= 0.40; //Constante � fin d'imposer une taxe en fonction de comment est utilis� le terrain 
	private final static double TENTE = 0.20;     //
	private String typeInstallation;
	private double tarif;
	
	public TerrainNu(String lib) {
		super(lib, "Terrain Nu", NBPLACE);
	}
	
	public void setTarif(String chx)
	{
		/**
		 * si le choix est egal a "caravane" alors appliquer la taxe "CARAVANE"
		 */
		if(chx.equals("Caravane")) 
		{
			tarif = CARAVANE;
			typeInstallation = "Caravane";
			/**
			 *  si le choix est egal a "Camping-car" alors appliquer la taxe "CAMPINGCAR"
			 */
		}else if(chx.equals("Camping-car"))
		{
			tarif = CAMPINGCAR;
			typeInstallation = "Camping-car";
			/**
			 * sinon le choix est egal a "tente" alors appliquer la taxe "TENTE"
			 */
		}else
		{
			tarif = TENTE;
			typeInstallation = "Tente";
		}
	}
	
	public String getTypeInstalation()
	{
		return typeInstallation;
	}

	public double getTarif() {
	
		return tarif;
	}

}